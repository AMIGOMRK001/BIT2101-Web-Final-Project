<?php
// Handle Club Addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_club'])) {
    $club_name = $conn->real_escape_string($_POST['club_name']);
    $description = $conn->real_escape_string($_POST['description']);
    $created_by = $_SESSION['user_id'];
    
    $conn->query("INSERT INTO clubs (name, description, created_by) VALUES ('$club_name', '$description', $created_by)");
}

// Handle Notice Addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_notice'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $author_id = $_SESSION['user_id'];
    
    $conn->query("INSERT INTO notices (title, content, author_id) VALUES ('$title', '$content', $author_id)");
}

// Handle Agent Assignment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['assign_agent'])) {
    $player_user_id = $_POST['player_user_id'];
    $agent_user_id = $_POST['agent_user_id'];
    
    $conn->query("UPDATE players SET agent_id = $agent_user_id WHERE user_id = $player_user_id");
}

// Fetch Data
$clubs = $conn->query("SELECT * FROM clubs");
$notices = $conn->query("SELECT * FROM notices ORDER BY created_at DESC");
$users = $conn->query("SELECT * FROM users");
$players = $conn->query("SELECT users.id, users.username FROM users JOIN players ON users.id = players.user_id");
$agents = $conn->query("SELECT id, username FROM users WHERE role = 'agent'");
?>

<div class="dashboard-grid">
    <!-- Club Management -->
    <div class="card">
        <h3>Manage Clubs</h3>
        <form method="POST" action="">
            <div class="form-group">
                <input type="text" name="club_name" placeholder="Club Name" required>
            </div>
            <div class="form-group">
                <textarea name="description" placeholder="Description"></textarea>
            </div>
            <button type="submit" name="add_club" class="btn">Add Club</button>
        </form>
        
        <h4>Existing Clubs</h4>
        <ul>
            <?php while($club = $clubs->fetch_assoc()): ?>
                <li><?php echo $club['name']; ?></li>
            <?php endwhile; ?>
        </ul>
    </div>

    <!-- Notice Board -->
    <div class="card">
        <h3>Post Notice</h3>
        <form method="POST" action="">
            <div class="form-group">
                <input type="text" name="title" placeholder="Title" required>
            </div>
            <div class="form-group">
                <textarea name="content" placeholder="Content" required></textarea>
            </div>
            <button type="submit" name="add_notice" class="btn">Post Notice</button>
        </form>
        
        <h4>Recent Notices</h4>
        <ul>
            <?php while($notice = $notices->fetch_assoc()): ?>
                <li>
                    <strong><?php echo $notice['title']; ?></strong><br>
                    <small><?php echo $notice['created_at']; ?></small><br>
                    <?php echo $notice['content']; ?>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>
    
    <!-- Agent Assignment -->
    <div class="card">
        <h3>Assign Agent to Player</h3>
        <form method="POST" action="">
            <div class="form-group">
                <label>Select Player</label>
                <select name="player_user_id">
                    <?php 
                    $players->data_seek(0); // Reset pointer
                    while($p = $players->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $p['id']; ?>"><?php echo $p['username']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Select Agent</label>
                <select name="agent_user_id">
                    <?php 
                    $agents->data_seek(0); // Reset pointer
                    while($a = $agents->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $a['id']; ?>"><?php echo $a['username']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <button type="submit" name="assign_agent" class="btn">Assign Agent</button>
        </form>
    </div>
    
    <!-- User List -->
    <div class="card">
        <h3>All Users</h3>
        <table>
            <tr>
                <th>Username</th>
                <th>Role</th>
                <th>Email</th>
            </tr>
            <?php while($user = $users->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $user['username']; ?></td>
                    <td><?php echo $user['role']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
