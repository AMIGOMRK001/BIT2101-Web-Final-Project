<?php
include 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];
?>

<div style="padding: 20px;">
    <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
    <p>Role: <?php echo ucfirst($role); ?></p>
    
    <?php
    if ($role === 'admin') {
        include 'admin_panel.php';
    } elseif ($role === 'player') {
        include 'player_profile.php';
    } else {
        echo "<p>Agent dashboard coming soon.</p>";
    }
    ?>
</div>

<?php include 'footer.php'; ?>
