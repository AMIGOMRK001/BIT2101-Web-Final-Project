<?php include 'header.php'; ?>

<div style="max-width: 1000px; margin: 0 auto; padding: 40px 20px;">
    <h1 style="text-align: center; margin-bottom: 40px;">Our Services</h1>
    
    <div class="dashboard-grid">
        <div class="card">
            <h3>Club Management</h3>
            <p>Complete administrative control over club operations, including roster management and scheduling.</p>
        </div>
        
        <div class="card">
            <h3>Agent Representation</h3>
            <p>Tools for agents to manage their portfolio of players, track contracts, and monitor performance.</p>
        </div>
        
        <div class="card">
            <h3>Player Development</h3>
            <p>Performance tracking, bio management, and career progression monitoring for athletes.</p>
        </div>

        <div class="card">
            <h3>Scouting Network</h3>
            <p>Connect with talent scouts and showcase player profiles to a wider audience.</p>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
