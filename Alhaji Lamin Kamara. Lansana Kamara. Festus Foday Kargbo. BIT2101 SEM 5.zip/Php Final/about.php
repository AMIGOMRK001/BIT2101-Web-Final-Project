<?php include 'header.php'; ?>

<div style="max-width: 800px; margin: 0 auto; padding: 40px 20px;">
    <h1 style="text-align: center; margin-bottom: 30px;">About Us</h1>
    
    <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <p style="margin-bottom: 20px;">
            SportsClub is a premier management platform designed to bridge the gap between players, agents, and club managers. 
            Founded in 2023, our mission is to digitize sports management and provide transparent, efficient tools for talent development.
        </p>
        
        <p style="margin-bottom: 20px;">
            We believe in the power of data and organization to unlock potential. Whether you are a grassroots club or a professional academy, 
            our system scales to meet your needs.
        </p>

        <h3>Our Vision</h3>
        <p>To be the leading digital ecosystem for sports talent management globally.</p>
    </div>
</div>

<?php include 'footer.php'; ?>
