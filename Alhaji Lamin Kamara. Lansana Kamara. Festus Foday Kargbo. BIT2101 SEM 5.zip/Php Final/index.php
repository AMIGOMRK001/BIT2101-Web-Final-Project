<?php include 'header.php'; ?>

<section class="hero" style="background: url('https://images.unsplash.com/photo-1461896836934-ffe607ba8211?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80') no-repeat center center/cover; height: 500px; display: flex; align-items: center; justify-content: center; color: white; text-align: center;">
    <div style="background: rgba(0,0,0,0.6); padding: 40px; border-radius: 10px;">
        <h1 style="font-size: 3rem; margin-bottom: 20px;">Welcome to SportsClub</h1>
        <p style="font-size: 1.2rem; margin-bottom: 30px;">Manage your team, track progress, and achieve greatness.</p>
        <?php if (!isset($_SESSION['user_id'])): ?>
            <a href="register.php" class="btn">Join Now</a>
        <?php else: ?>
            <a href="dashboard.php" class="btn">Go to Dashboard</a>
        <?php endif; ?>
    </div>
</section>

<section class="features" style="padding: 50px 0; text-align: center;">
    <h2 style="margin-bottom: 40px;">Why Choose Us?</h2>
    <div class="dashboard-grid">
        <div class="card">
            <h3>Professional Management</h3>
            <p>Comprehensive tools for club managers and agents to oversee player development.</p>
        </div>
        <div class="card">
            <h3>Player Tracking</h3>
            <p>Detailed profiles and statistics for every player in the club.</p>
        </div>
        <div class="card">
            <h3>Seamless Communication</h3>
            <p>Integrated notice board and reporting features to keep everyone in the loop.</p>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
