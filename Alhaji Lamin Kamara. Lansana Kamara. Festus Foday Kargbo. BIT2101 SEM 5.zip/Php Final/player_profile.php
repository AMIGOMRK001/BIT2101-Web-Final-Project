<?php
$user_id = $_SESSION['user_id'];

// Handle Profile Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $full_name = $conn->real_escape_string($_POST['full_name']);
    $position = $conn->real_escape_string($_POST['position']);
    $bio = $conn->real_escape_string($_POST['bio']);
    
    $conn->query("UPDATE players SET full_name='$full_name', position='$position', bio='$bio' WHERE user_id=$user_id");
}

// Fetch Player Data
$player_result = $conn->query("SELECT * FROM players WHERE user_id=$user_id");
$player = $player_result->fetch_assoc();

// Fetch Notices
$notices = $conn->query("SELECT * FROM notices ORDER BY created_at DESC LIMIT 5");
?>

<div class="dashboard-grid">
    <!-- Profile Edit -->
    <div class="card">
        <h3>My Profile</h3>
        <form method="POST" action="">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="full_name" value="<?php echo $player['full_name'] ?? ''; ?>">
            </div>
            <div class="form-group">
                <label>Position</label>
                <input type="text" name="position" value="<?php echo $player['position'] ?? ''; ?>">
            </div>
            <div class="form-group">
                <label>Bio</label>
                <textarea name="bio"><?php echo $player['bio'] ?? ''; ?></textarea>
            </div>
            <button type="submit" name="update_profile" class="btn">Update Profile</button>
        </form>
    </div>

    <!-- Notices View -->
    <div class="card">
        <h3>Club Notices</h3>
        <?php if ($notices->num_rows > 0): ?>
            <ul>
                <?php while($notice = $notices->fetch_assoc()): ?>
                    <li style="margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px;">
                        <strong><?php echo $notice['title']; ?></strong><br>
                        <small><?php echo $notice['created_at']; ?></small>
                        <p><?php echo $notice['content']; ?></p>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No notices yet.</p>
        <?php endif; ?>
    </div>
</div>
